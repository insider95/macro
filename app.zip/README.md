Шаги: 1) py -3.11 -m venv .venv  2) .\.venv\Scripts\Activate.ps1  3) pip install -r requirements.txt  4) python -m playwright install chromium  5) .env и python main.py
