# app/handlers/debug.py
from aiogram import Router, types
from aiogram.filters import Command
from datetime import datetime, timedelta, timezone
from app.db import get_user, list_blacklist, events_between, dbg_counts, dbg_peek

router = Router(name="debug")

@router.message(Command("debug"))
async def cmd_debug(msg: types.Message):
    u = get_user(msg.chat.id)
    bl = list_blacklist(msg.chat.id)

    now = datetime.now(timezone.utc)
    start_w = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    end_w = start_w + timedelta(days=7)
    start_m = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    end_m = (start_m.replace(month=start_m.month+1, day=1) 
             if start_m.month < 12 else start_m.replace(year=start_m.year+1, month=1, day=1))

    week = events_between(start_w, end_w, u['country'], u['importance_min'], u['importance_max'], bl)
    month = events_between(start_m, end_m, u['country'], u['importance_min'], u['importance_max'], bl)

    total, by_country, latest = dbg_counts()

    text = [
        "<b>DEBUG</b>",
        f"User: country={u['country']} imp={u['importance_min']}-{u['importance_max']} alerts={u['alert_mode']}",
        f"Blacklist: {', '.join(bl) if bl else '—'}",
        f"events total: {total}",
        f"by country: {by_country}",
        f"latest (5): {latest}",
        f"week found: {len(week)} | month found: {len(month)}"
    ]
    await msg.answer("\n".join(text))
