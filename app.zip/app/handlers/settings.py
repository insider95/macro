from aiogram import Router, types, F
from aiogram.filters import Command
from ..db import get_user, get_blacklist, alert_mode_label

router = Router()

@router.message(Command("settings"))
@router.message(F.text.lower() == "мои настройки")
async def my_settings(msg: types.Message):
    user = get_user(msg.chat.id)
    if not user:
        await msg.answer("Сначала нажми /start"); return
    bl = get_blacklist(msg.chat.id)
    txt = (
        "<b>Мои настройки</b>\n"
        f"• Страна: {user['country']}\n"
        f"• Важность: {user['importance_min']}-{user['importance_max']} (1=не особо, 2=средние, 3=серьезные)\n"
        f"• Вариант уведомлений: {alert_mode_label(user['alert_mode'])}\n"
        f"• Черный список: {len(bl)} отчётов\n\n"
        "Команды:\n"
        "— /importance или «важность событий»\n"
        "— /alerts или «варианты уведомлений»\n"
        "— /blacklist или «черный список»"
    )
    await msg.answer(txt)
