# app/handlers/range.py
from __future__ import annotations
from datetime import datetime, timedelta, timezone
from aiogram import Router, types
from aiogram.filters import Command

from app.db import get_user, list_blacklist, events_between
from app.formatting import format_event_for_user, chunk_messages

router = Router(name="range")

EMPTY_MSG = "Событий не найдено по твоим фильтрам."

def _filtered_events_for_user(user: dict, start_utc: datetime, end_utc: datetime):
    """
    Гарантируем, что учитываются все личные фильтры: страна, важность, чёрный список.
    Плюс дополнительная «страховка» по важности, даже если когда‑то поменяется SQL.
    """
    bl = list_blacklist(user["chat_id"])
    evs = events_between(
        start_utc, end_utc,
        country=user["country"],
        imp_min=user["importance_min"],
        imp_max=user["importance_max"],
        blacklist_patterns=bl,
    )
    # safety‑filter на всякий случай
    imp_min = int(user["importance_min"])
    imp_max = int(user["importance_max"])
    evs = [e for e in evs if isinstance(e.get("importance"), int) and imp_min <= e["importance"] <= imp_max]
    return evs

def _make_range_reply(user: dict, start_utc: datetime, end_utc: datetime) -> list[str]:
    events = _filtered_events_for_user(user, start_utc, end_utc)
    if not events:
        return [EMPTY_MSG]
    blocks = [format_event_for_user(e, tz_name="Europe/Moscow") for e in events]
    return chunk_messages(blocks, limit=8)

@router.message(Command("week"))
async def cmd_week(msg: types.Message):
    user = get_user(msg.chat.id)
    now = datetime.now(timezone.utc)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(days=7)
    for text in _make_range_reply(user, start, end):
        await msg.answer(text)

@router.message(Command("nextweek"))
async def cmd_nextweek(msg: types.Message):
    user = get_user(msg.chat.id)
    now = datetime.now(timezone.utc)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=7)
    end = start + timedelta(days=7)
    for text in _make_range_reply(user, start, end):
        await msg.answer(text)

@router.message(Command("month"))
async def cmd_month(msg: types.Message):
    user = get_user(msg.chat.id)
    now = datetime.now(timezone.utc)
    start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    if start.month == 12:
        end = start.replace(year=start.year + 1, month=1)
    else:
        end = start.replace(month=start.month + 1)
    for text in _make_range_reply(user, start, end):
        await msg.answer(text)
