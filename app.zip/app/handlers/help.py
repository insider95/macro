# app/handlers/help.py
from aiogram import Router, types
from aiogram.filters import Command
from aiogram.utils.keyboard import ReplyKeyboardBuilder

router = Router(name="help")

HELP_TEXT = (
    "<b>Доступные команды:</b>\n"
    "/start — приветствие и ссылка на канал\n"
    "/settings — мои настройки\n"
    "/importance — выбрать важность (1–3)\n"
    "/alerts — выбрать уведомления (24ч / 30м / факт)\n"
    "/blacklist — чёрный список паттернов\n"
    "/week — события этой недели\n"
    "/nextweek — события следующей недели\n"
    "/month — события в этом месяце\n"
    "/help — список команд\n"
)

def menu_kb() -> types.ReplyKeyboardMarkup:
    kb = ReplyKeyboardBuilder()
    kb.button(text="📋 Команды")
    kb.button(text="🗓 Эта неделя")
    kb.button(text="➡️ Следующая неделя")
    kb.button(text="📆 Этот месяц")
    kb.adjust(2)
    return kb.as_markup(resize_keyboard=True)

@router.message(Command("help"))
async def cmd_help(msg: types.Message):
    await msg.answer(HELP_TEXT, reply_markup=menu_kb())

@router.message(lambda m: m.text == "📋 Команды")
async def btn_commands(msg: types.Message):
    await cmd_help(msg)

@router.message(lambda m: m.text == "🗓 Эта неделя")
async def btn_week(msg: types.Message):
    # просто прокинем к /week
    from app.handlers.range import this_week
    await this_week(msg)

@router.message(lambda m: m.text == "➡️ Следующая неделя")
async def btn_nextweek(msg: types.Message):
    from app.handlers.range import next_week
    await next_week(msg)

@router.message(lambda m: m.text == "📆 Этот месяц")
async def btn_month(msg: types.Message):
    from app.handlers.range import this_month
    await this_month(msg)
