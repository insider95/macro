from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from ..db import set_alert_mode, alert_mode_label, get_user

router = Router()

def kb_alerts():
    kb = InlineKeyboardBuilder()
    kb.button(text="1) Только за сутки", callback_data="am:24h")
    kb.button(text="2) Только за 30 минут", callback_data="am:30m")
    kb.button(text="3) Только факты", callback_data="am:fact")
    kb.button(text="4) Все 3 сразу", callback_data="am:all")
    kb.adjust(1)
    return kb.as_markup()

@router.message(Command("alerts"))
@router.message(F.text.lower() == "варианты уведомлений")
async def alerts_menu(msg: types.Message):
    user = get_user(msg.chat.id)
    if not user:
        await msg.answer("Сначала нажми /start"); return
    await msg.answer("<b>Варианты уведомлений</b>\nВыбери один из 4 вариантов:", reply_markup=kb_alerts())

@router.callback_query(F.data.startswith("am:"))
async def alerts_set(call: types.CallbackQuery):
    code = call.data.split(":",1)[1]  # 24h / 30m / fact / all
    set_alert_mode(call.from_user.id, code)
    await call.message.edit_text(f"Ок. Вариант уведомлений: {alert_mode_label(code)}")
    await call.answer()
