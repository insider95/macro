from aiogram import Router, types
from aiogram.filters import Command
from ..db import get_user, get_upcoming_events
router = Router()
@router.message(Command("next"))
async def cmd_next(msg: types.Message):
    user = get_user(msg.chat.id)
    if not user:
        await msg.answer("Сначала /start"); return
    evs = get_upcoming_events(user['country'], user['importance_min'], user['importance_max'], 10)
    if not evs:
        await msg.answer("Событий не найдено."); return
    await msg.answer("\n".join([f"- {e['local_date']} NY | {e['event_name']} | важн {e['importance']} | прогноз {e['forecast']} | пред {e['previous']}" for e in evs]))
