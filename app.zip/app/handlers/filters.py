from aiogram import Router, types
from aiogram.filters import Command
from ..db import get_user, upsert_user

router = Router()

@router.message(Command("filters"))
async def cmd_filters(msg: types.Message):
    """
    Показывает текущие фильтры.
    Если переданы аргументы (например: /filters US 2 3), применяет их.
    """
    args = msg.text.split()
    if len(args) == 4:
        # формат: /filters US 2 3
        try:
            _, country, imin, imax = args
            upsert_user(msg.chat.id, country.upper(), int(imin), int(imax))
            await msg.answer(f"Ок. Фильтры обновлены: {country.upper()} {imin}-{imax}")
            return
        except Exception:
            await msg.answer("Формат: /filters US 2 3")
            return

    # просто показать текущие
    user = get_user(msg.chat.id)
    if not user:
        await msg.answer("Сначала нажми /start")
        return
    await msg.answer(
        f"Текущие фильтры:\n"
        f"• Страна: {user['country']}\n"
        f"• Важность: {user['importance_min']}-{user['importance_max']}\n\n"
        f"Изменить: /filters US 2 3"
    )
