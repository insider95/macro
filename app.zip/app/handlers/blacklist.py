# app/handlers/blacklist.py
from aiogram import Router, F, types
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext

from app.db import list_blacklist, add_blacklist, remove_blacklist

router = Router(name="blacklist")

class BLStates(StatesGroup):
    waiting_pattern = State()

def _kb(patterns: list[str]) -> types.InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    if patterns:
        for p in patterns:
            kb.button(text=f"❌ {p}", callback_data=f"bl_del:{p}")
        kb.adjust(2)
    kb.button(text="➕ добавить", callback_data="bl_add")
    return kb.as_markup()

@router.message(Command("blacklist"))
async def cmd_blacklist(msg: types.Message, state: FSMContext):
    await state.clear()
    patterns = list_blacklist(msg.chat.id)
    await msg.answer("Чёрный список. Нажми, чтобы удалить. Можно добавить свой паттерн.",
                     reply_markup=_kb(patterns))

@router.callback_query(F.data == "bl_add")
async def cb_add(call: types.CallbackQuery, state: FSMContext):
    await state.set_state(BLStates.waiting_pattern)
    await call.message.answer("Пришли текст/паттерн, который нужно занести в чёрный список.\nНапример: CPI, FOMC, Fed Chair Powell.\nНапиши /cancel чтобы отменить.")
    await call.answer()

@router.message(Command("cancel"))
async def cancel(msg: types.Message, state: FSMContext):
    await state.clear()
    await msg.answer("Ок, отменил.")

@router.message(BLStates.waiting_pattern, F.text)
async def got_pattern(msg: types.Message, state: FSMContext):
    pattern = msg.text.strip()
    if len(pattern) < 2:
        return await msg.reply("Слишком коротко. Введи от 2 символов или /cancel.")
    add_blacklist(msg.chat.id, pattern)
    await state.clear()
    patterns = list_blacklist(msg.chat.id)
    await msg.answer(f"Добавил в blacklist: <b>{pattern}</b>", reply_markup=_kb(patterns))

@router.callback_query(F.data.startswith("bl_del:"))
async def cb_delete(call: types.CallbackQuery, state: FSMContext):
    await state.clear()
    pattern = call.data.split(":", 1)[1]
    remove_blacklist(call.message.chat.id, pattern)
    await call.answer("Удалено")
    patterns = list_blacklist(call.message.chat.id)
    await call.message.edit_reply_markup(reply_markup=_kb(patterns))
