# app/handlers/dbinfo.py
import os
from aiogram import Router, types
from aiogram.filters import Command

from app.db import _conn
router = Router(name="dbinfo")

@router.message(Command("dbinfo"))
async def cmd_dbinfo(msg: types.Message):
    db_path = os.getenv("SQLITE_PATH") or os.getenv("DB_PATH") or "macro.db"
    exists = os.path.exists(db_path)
    size = os.path.getsize(db_path) if exists else 0
    try:
        with _conn() as c:
            tables = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            ev_cnt = c.execute("SELECT COUNT(*) FROM events").fetchone()[0] if "events" in tables else 0
    except Exception as e:
        tables, ev_cnt = [f"error: {e}"], 0
    await msg.answer(
        f"<b>DB path:</b> {db_path}\n"
        f"<b>Exists:</b> {exists}\n"
        f"<b>Size:</b> {size} bytes\n"
        f"<b>Tables:</b> {tables}\n"
        f"<b>events count:</b> {ev_cnt}"
    )
