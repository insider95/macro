# app/handlers/admin.py
from __future__ import annotations
import os
from aiogram import Router, types
from aiogram.filters import Command

# безопасный разбор OWNER_ID из .env
def _int(v: str | None, default: int = 0) -> int:
    if not v:
        return default
    try:
        return int(v.strip())
    except ValueError:
        # если вдруг в .env было "2123 # комментарий" — вырежем всё после #
        return int(v.split("#", 1)[0].strip())

OWNER_ID = _int(os.getenv("OWNER_ID"), 0)

router = Router(name="admin")

# --- Вспомогательный ответ, если не админ
async def _guard_owner(msg: types.Message) -> bool:
    if msg.from_user.id != OWNER_ID:
        await msg.answer("⛔ Только для администратора.")
        return False
    return True

# ==========================
# /testparse — посмотреть, парсит ли календарь (без записи в БД)
# ==========================
@router.message(Command("testparse"))
async def cmd_testparse(msg: types.Message):
    try:
        from app.scraper import scrape_investing_us
        events = await scrape_investing_us()
        n = len(events)
        preview = events[:2]
        await msg.answer(f"Парсер нашёл <b>{n}</b> событий.\nПример: {preview}")
    except Exception as e:
        await msg.answer(f"❌ testparse error: {e}")

# ==========================
# /refresh — спарсить и записать в БД (для админа)
# ==========================
@router.message(Command("refresh"))
async def cmd_refresh(msg: types.Message):
    if not await _guard_owner(msg):
        return
    try:
        from app.scraper import scrape_and_upsert
        await msg.answer("⏳ Запускаю парсер и запись в БД…")
        await scrape_and_upsert()
        # покажем итоговое число в таблице events
        from app.db import _conn
        with _conn() as c:
            cnt = c.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        await msg.answer(f"✅ Готово. В таблице events сейчас записей: <b>{cnt}</b>")
    except Exception as e:
        await msg.answer(f"❌ refresh error: {e}")

# ==========================
# /refresh_now — то же самое, но без проверки админа (для диагностики!)
# НЕ оставляй это в продакшене.
# ==========================
@router.message(Command("refresh_now"))
async def cmd_refresh_now(msg: types.Message):
    try:
        from app.scraper import scrape_and_upsert
        await msg.answer("⏳ [diag] Запускаю парсер и запись в БД…")
        await scrape_and_upsert()
        from app.db import _conn
        with _conn() as c:
            cnt = c.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        await msg.answer(f"✅ [diag] Готово. В таблице events сейчас записей: <b>{cnt}</b>")
    except Exception as e:
        await msg.answer(f"❌ [diag] refresh_now error: {e}")
