from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from ..db import set_importance, get_user

router = Router()

def kb_importance():
    kb = InlineKeyboardBuilder()
    kb.button(text="1) Серьезные", callback_data="imp:3")
    kb.button(text="2) Средние", callback_data="imp:2")
    kb.button(text="3) Не особо важные", callback_data="imp:1")
    kb.button(text="4) Все сразу", callback_data="imp:all")
    kb.adjust(1)
    return kb.as_markup()

@router.message(Command("importance"))
@router.message(F.text.lower() == "важность событий")
async def importance_menu(msg: types.Message):
    user = get_user(msg.chat.id)
    if not user:
        await msg.answer("Сначала нажми /start"); return
    await msg.answer(
        "<b>Важность событий</b>\nПо умолчанию — все 3. Выбери вариант:",
        reply_markup=kb_importance()
    )

@router.callback_query(F.data.startswith("imp:"))
async def importance_set(call: types.CallbackQuery):
    choice = call.data.split(":",1)[1]
    if choice == "all":
        imin, imax = 1, 3
    else:
        level = int(choice)  # 1/2/3
        imin, imax = level, level
    set_importance(call.from_user.id, imin, imax)
    await call.message.edit_text(f"Готово. Важность обновлена: {imin}-{imax}")
    await call.answer()
