from aiogram import Router, types
from aiogram.filters import Command
from ..db import upsert_user
from ..config import DEFAULT_COUNTRY, DEFAULT_IMPORTANCE_MIN, DEFAULT_IMPORTANCE_MAX

router = Router()

def greet_text(user: types.User) -> str:
    nick = user.first_name or user.username or "друг"
    return (
        f"Привет, {nick}. Я макро-бот, созданный админом канала "
        f"<a href=\"https://t.me/+5EYCKuBCpfo1NjJi\">CRYPTO TARGET</a>.\n\n"
        f"Я буду уведомлять тебя о важных макро‑событиях, чтобы ты был в курсе всего и ничего не упустил.\n\n"
        f"Меню:\n"
        f"• <b>мои настройки</b>\n"
        f"• <b>важность событий</b>\n"
        f"• <b>черный список</b>\n"
        f"• <b>варианты уведомлений</b>\n\n"
        f"Подсказка: просто напиши одно из этих названий, или используй команды: /settings /importance /blacklist /alerts"
    )

@router.message(Command("start"))
async def cmd_start(msg: types.Message):
    upsert_user(msg.chat.id, DEFAULT_COUNTRY, DEFAULT_IMPORTANCE_MIN, DEFAULT_IMPORTANCE_MAX)
    await msg.answer(greet_text(msg.from_user), disable_web_page_preview=True)
