# app/db.py
from __future__ import annotations

# безопасная загрузка .env
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

import os, sqlite3
from contextlib import closing
from datetime import datetime, timedelta
from typing import List, Tuple, Optional, Dict, Any

# === путь к БД ===
DB_PATH = os.getenv("SQLITE_PATH") or os.getenv("DB_PATH") or "macro.db"
_db_dir = os.path.dirname(DB_PATH)
if _db_dir:
    os.makedirs(_db_dir, exist_ok=True)

def _conn():
    return sqlite3.connect(DB_PATH, detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES)

# ---------- helpers ----------
def _table_info(c: sqlite3.Connection, table: str) -> list[tuple]:
    return c.execute(f"PRAGMA table_info({table})").fetchall()

def _has_column(c: sqlite3.Connection, table: str, col: str) -> bool:
    return any(r[1] == col for r in _table_info(c, table))

def _col_notnull(c: sqlite3.Connection, table: str, col: str) -> bool:
    for r in _table_info(c, table):
        if r[1] == col:
            return bool(r[3])  # r[3] == notnull flag
    return False

def _events_time_cols(c: sqlite3.Connection) -> Dict[str, bool]:
    """Какие временные колонки есть и их NOT NULL флаги."""
    has_dt = _has_column(c, "events", "dt_utc")
    has_date = _has_column(c, "events", "date_utc")
    return {
        "has_dt": has_dt,
        "has_date": has_date,
        "date_notnull": _col_notnull(c, "events", "date_utc") if has_date else False,
        "dt_notnull": _col_notnull(c, "events", "dt_utc") if has_dt else False,
    }

# ---------- миграции ----------
def _migrate_schema():
    with closing(_conn()) as c, c:
        c.execute("""
        CREATE TABLE IF NOT EXISTS users(
            chat_id INTEGER PRIMARY KEY,
            country TEXT DEFAULT 'US',
            importance_min INTEGER DEFAULT 2,
            importance_max INTEGER DEFAULT 3,
            alert_mode TEXT DEFAULT 't24,t30,fact',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );""")

        c.execute("""
        CREATE TABLE IF NOT EXISTS events(
            id TEXT PRIMARY KEY,
            dt_utc TIMESTAMP,              -- может быть NULL в старой схеме
            country TEXT,
            name TEXT,
            importance INTEGER,
            previous TEXT,
            forecast TEXT,
            actual TEXT
        );""")

        # добираем недостающие поля (на случай очень старых схем)
        for col, ddl in [
            ("country", "ALTER TABLE events ADD COLUMN country TEXT;"),
            ("name", "ALTER TABLE events ADD COLUMN name TEXT;"),
            ("importance", "ALTER TABLE events ADD COLUMN importance INTEGER;"),
            ("previous", "ALTER TABLE events ADD COLUMN previous TEXT;"),
            ("forecast", "ALTER TABLE events ADD COLUMN forecast TEXT;"),
            ("actual", "ALTER TABLE events ADD COLUMN actual TEXT;"),
        ]:
            if not _has_column(c, "events", col):
                c.execute(ddl)

        c.execute("""
        CREATE TABLE IF NOT EXISTS alerts(
            event_id TEXT,
            chat_id INTEGER,
            kind TEXT,
            sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY(event_id, chat_id, kind)
        );""")

        c.execute("""
        CREATE TABLE IF NOT EXISTS blacklist(
            chat_id INTEGER,
            pattern TEXT,
            PRIMARY KEY(chat_id, pattern)
        );""")

def init_db() -> None:
    _migrate_schema()

# ---------- users ----------
def get_user(chat_id: int) -> Dict[str, Any]:
    with closing(_conn()) as c, c:
        row = c.execute(
            "SELECT chat_id,country,importance_min,importance_max,alert_mode FROM users WHERE chat_id=?",
            (chat_id,)
        ).fetchone()
        if row:
            return {"chat_id": row[0], "country": row[1], "importance_min": row[2], "importance_max": row[3], "alert_mode": row[4]}
        c.execute("INSERT OR IGNORE INTO users(chat_id) VALUES(?)", (chat_id,))
        return get_user(chat_id)

def update_user_settings(chat_id: int, **kwargs) -> None:
    if not kwargs: return
    fields = ", ".join(f"{k}=?" for k in kwargs)
    vals = list(kwargs.values()) + [chat_id]
    with closing(_conn()) as c, c:
        c.execute(f"UPDATE users SET {fields} WHERE chat_id=?", vals)

def upsert_user(chat_id: int, country: str | None = None, importance_min: int | None = None,
                importance_max: int | None = None, **kwargs) -> None:
    with closing(_conn()) as c, c:
        c.execute("INSERT OR IGNORE INTO users(chat_id) VALUES(?)", (chat_id,))
        upd: Dict[str, Any] = {}
        if country is not None: upd["country"] = country
        if importance_min is not None: upd["importance_min"] = int(importance_min)
        if importance_max is not None: upd["importance_max"] = int(importance_max)
        upd.update(kwargs)
        if upd:
            fields = ", ".join(f"{k}=?" for k in upd)
            vals = list(upd.values()) + [chat_id]
            c.execute(f"UPDATE users SET {fields} WHERE chat_id=?", vals)

# ---------- blacklist ----------
def add_blacklist(chat_id: int, pattern: str) -> None:
    with closing(_conn()) as c, c:
        c.execute("INSERT OR IGNORE INTO blacklist(chat_id, pattern) VALUES(?,?)", (chat_id, pattern))

def remove_blacklist(chat_id: int, pattern: str) -> None:
    with closing(_conn()) as c, c:
        c.execute("DELETE FROM blacklist WHERE chat_id=? AND pattern=?", (chat_id, pattern))

def list_blacklist(chat_id: int) -> List[str]:
    with closing(_conn()) as c, c:
        return [r[0] for r in c.execute("SELECT pattern FROM blacklist WHERE chat_id=? ORDER BY pattern", (chat_id,)).fetchall()]

# ---------- upsert events ----------
def upsert_events(rows: List[Tuple]):
    """
    rows: (id, dt(datetime|str), country, name, importance, previous, forecast, actual)
    Вставляет и/или обновляет обе временные колонки, если обе присутствуют.
    """
    with closing(_conn()) as c, c:
        info = _events_time_cols(c)
        has_dt, has_date = info["has_dt"], info["has_date"]

        normed = []
        for (id_, dt_val, country, name, importance, previous, forecast, actual) in rows:
            if isinstance(dt_val, datetime):
                dt = dt_val.strftime("%Y-%m-%d %H:%M:%S")
            else:
                dt = str(dt_val).replace("T", " ").replace("Z", "")
            country = "US" if (country or "").upper() in {"US", "USA", "UNITED STATES"} else country
            normed.append((id_, dt, country, name, int(importance), previous, forecast, actual))

        cols = ["id", "country", "name", "importance", "previous", "forecast", "actual"]
        time_cols = []
        if has_dt: time_cols.append("dt_utc")
        if has_date: time_cols.append("date_utc")
        # вставляем обе временные колонки, если они есть
        insert_cols = ["id"] + time_cols + ["country", "name", "importance", "previous", "forecast", "actual"]
        placeholders = ",".join("?" * len(insert_cols))

        # построим кортежи значений под insert_cols
        values = []
        for (id_, dt, country, name, importance, previous, forecast, actual) in normed:
            row = [id_]
            for _ in time_cols:
                row.append(dt)
            row += [country, name, importance, previous, forecast, actual]
            values.append(tuple(row))

        update_sets = []
        for tc in time_cols:
            update_sets.append(f"{tc}=excluded.{tc}")
        update_sets += [
            "country=excluded.country",
            "name=excluded.name",
            "importance=excluded.importance",
            "previous=excluded.previous",
            "forecast=excluded.forecast",
            "actual=excluded.actual",
        ]
        update_sql = ", ".join(update_sets)

        sql = f"""
        INSERT INTO events({",".join(insert_cols)})
        VALUES({placeholders})
        ON CONFLICT(id) DO UPDATE SET
            {update_sql}
        """
        c.executemany(sql, values)

# ---------- select events ----------
def events_between(start_dt: datetime, end_dt: datetime, country: str = "US",
                   imp_min: int = 1, imp_max: int = 3,
                   blacklist_patterns: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    with closing(_conn()) as c, c:
        info = _events_time_cols(c)
        # какую колонку использовать для сравнения/сортировки
        tcol = "dt_utc" if info["has_dt"] else ("date_utc" if info["has_date"] else "dt_utc")
        variants = {"US", "USA", "United States", "U.S.", country}
        placeholders = ",".join("?" * len(variants))
        sql = f"""
            SELECT id, {tcol}, country, name, importance, previous, forecast, actual
            FROM events
            WHERE datetime({tcol}) >= datetime(?)
              AND datetime({tcol}) < datetime(?)
              AND country IN ({placeholders})
              AND importance BETWEEN ? AND ?
            ORDER BY datetime({tcol}) ASC
        """
        params = [start_dt.strftime("%Y-%m-%d %H:%M:%S"),
                  end_dt.strftime("%Y-%m-%d %H:%M:%S"),
                  *variants, imp_min, imp_max]
        rows = c.execute(sql, params).fetchall()

    out: List[Dict[str, Any]] = []
    for r in rows:
        name = r[3]
        if blacklist_patterns and any(p.lower() in name.lower() for p in blacklist_patterns):
            continue
        out.append({"id": r[0], "dt_utc": r[1], "country": r[2], "name": name,
                    "importance": r[4], "previous": r[5], "forecast": r[6], "actual": r[7]})
    return out

# ---------- backcompat ----------
def get_upcoming_events(country="US", imp_min=1, imp_max=3, blacklist_or_limit=None, *rest, **kwargs):
    blacklist_patterns = kwargs.pop("blacklist_patterns", None)
    limit = kwargs.pop("limit", 20)
    if isinstance(blacklist_or_limit, int):
        limit = blacklist_or_limit
    elif isinstance(blacklist_or_limit, (list, tuple, set)):
        blacklist_patterns = list(blacklist_or_limit)
        if rest and isinstance(rest[0], int): limit = rest[0]
    start_dt = kwargs.pop("start_dt", datetime.utcnow())
    end_dt = kwargs.pop("end_dt", start_dt + timedelta(days=14))
    rows = events_between(start_dt, end_dt, country, imp_min, imp_max, blacklist_patterns or [])
    if limit and limit > 0: rows = rows[:limit]
    return rows

def all_users() -> list[dict]:
    with closing(_conn()) as c, c:
        return [{"chat_id": row[0]} for row in c.execute("SELECT chat_id FROM users ORDER BY created_at ASC")]

def get_blacklist(chat_id: int) -> list[str]:
    return list_blacklist(chat_id)

def alert_mode_label(mode: str) -> str:
    mapping = {"t24": "За 24ч", "t30": "За 30м", "fact": "Факт"}
    parts = [mapping[m.strip()] for m in (mode or "").split(",") if m.strip() in mapping]
    return ", ".join(parts) if parts else (mode or "")

def set_importance(chat_id: int, min_level: int | None = None, max_level: int | None = None) -> None:
    updates = {}
    if min_level is not None: updates["importance_min"] = int(min_level)
    if max_level is not None: updates["importance_max"] = int(max_level)
    if updates: update_user_settings(chat_id, **updates)

def set_alert_mode(chat_id: int, mode: str) -> None:
    update_user_settings(chat_id, alert_mode=mode)

# ---------- debug ----------
def dbg_counts():
    with closing(_conn()) as c, c:
        info = _events_time_cols(c)
        tcol = "dt_utc" if info["has_dt"] else ("date_utc" if info["has_date"] else "dt_utc")
        total = c.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        by_country = dict(c.execute("SELECT country, COUNT(*) FROM events GROUP BY country").fetchall())
        latest = [row[0] for row in c.execute(f"SELECT name FROM events ORDER BY datetime({tcol}) DESC LIMIT 5").fetchall()]
        return total, by_country, latest

def dbg_peek(limit=10):
    with closing(_conn()) as c, c:
        info = _events_time_cols(c)
        tcol = "dt_utc" if info["has_dt"] else ("date_utc" if info["has_date"] else "dt_utc")
        return c.execute(
            f"SELECT id, {tcol}, country, name, importance FROM events ORDER BY datetime({tcol}) DESC LIMIT ?",
            (limit,),
        ).fetchall()
