# app/scraper.py
from __future__ import annotations

import os
import re
import hashlib
from datetime import datetime, timezone
from typing import List, Dict

import httpx
from bs4 import BeautifulSoup
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

# .env обязательно подхватим
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

# ---------- ENV ----------
WIDGET_BASE = "https://sslecal2.investing.com/index.php"
INVESTING_COUNTRIES = os.getenv("INVESTING_COUNTRIES", "5")      # 5 = US
INVESTING_CALTYPE   = os.getenv("INVESTING_CALTYPE",   "week")   # day|week|month
INVESTING_LANG      = os.getenv("INVESTING_LANG",      "7")      # у тебя RU = 7
INVESTING_TZ_ID     = os.getenv("INVESTING_TZ_ID",     "")
USE_PLAYWRIGHT      = os.getenv("USE_PLAYWRIGHT",      "0") == "1"  # httpx быстрее, PW как fallback

HEADERS = {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "accept-language": "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",   # <- просим русскую локаль
    "referer": "https://www.investing.com/webmaster-tools/economic-calendar",
}

SAVE_DEBUG_HTML = True
DEBUG_HTML_PATH = "data/last_calendar.html"


def build_url() -> str:
    params = {
        "columns": "exc_flags,exc_currency,exc_importance,exc_event,exc_actual,exc_forecast,exc_previous,exc_time",
        "features": "datepicker,timezone",
        "countries": INVESTING_COUNTRIES,
        "calType": INVESTING_CALTYPE,
        "lang": INVESTING_LANG,
    }
    if INVESTING_TZ_ID:
        params["timeZone"] = INVESTING_TZ_ID
    q = "&".join(f"{k}={v}" for k, v in params.items())
    return f"{WIDGET_BASE}?{q}"


class Http403(Exception):
    ...


# ---------- загрузка ----------
@retry(reraise=True, stop=stop_after_attempt(3), wait=wait_exponential(1, 1, 5),
       retry=retry_if_exception_type(httpx.HTTPError))
async def fetch_http() -> str:
    url = build_url()
    async with httpx.AsyncClient(timeout=25, headers=HEADERS, follow_redirects=True) as c:
        r = await c.get(url)
        if r.status_code == 403:
            raise Http403("403")
        r.raise_for_status()
        html = r.text
    if SAVE_DEBUG_HTML:
        os.makedirs(os.path.dirname(DEBUG_HTML_PATH), exist_ok=True)
        with open(DEBUG_HTML_PATH, "w", encoding="utf-8") as f:
            f.write(html)
    print(f"[scraper] httpx got html length={len(html)} url={url}")
    return html


async def fetch_playwright() -> str:
    from playwright.async_api import async_playwright
    url = build_url()
    async with async_playwright() as pw:
        br = await pw.chromium.launch(headless=True)
        ctx = await br.new_context(user_agent=HEADERS["user-agent"], locale="ru-RU")
        p = await ctx.new_page()
        await p.set_extra_http_headers(HEADERS)
        await p.goto(url, wait_until="domcontentloaded", timeout=90000)
        # ждём строки событий в любом варианте
        await p.wait_for_selector('[id^="eventRow_"], tr.js-event-item, tr[data-event-datetime]', timeout=60000)
        html = await p.content()
        await br.close()
    if SAVE_DEBUG_HTML:
        os.makedirs(os.path.dirname(DEBUG_HTML_PATH), exist_ok=True)
        with open(DEBUG_HTML_PATH, "w", encoding="utf-8") as f:
            f.write(html)
    print(f"[scraper] playwright got html length={len(html)} url={url}")
    return html


async def fetch_calendar() -> str:
    if not USE_PLAYWRIGHT:
        try:
            return await fetch_http()
        except Http403:
            return await fetch_playwright()
    # если принудительно включён PW
    try:
        return await fetch_playwright()
    except Exception:
        return await fetch_http()


# ---------- парсинг ----------
def _stable_id(name: str, dt_utc_iso: str, country: str, importance: int) -> str:
    base = f"{name}|{dt_utc_iso}|{country}|{importance}"
    return hashlib.sha1(base.encode("utf-8")).hexdigest()[:32]


def parse_events(html: str) -> List[Dict]:
    soup = BeautifulSoup(html, "lxml")
    # ищем строки событий независимо от языка/вёрстки
    rows = soup.select('tr[id^="eventRow_"]') or soup.select("tr.js-event-item") or soup.select("tr[data-event-datetime]")
    out: List[Dict] = []

    for tr in rows:
        # ISO‑время UTC в data-атрибуте (не зависит от локали)
        dt_attr = tr.get("data-event-datetime") or tr.get("data-event-datetime2")
        if not dt_attr:
            td_time = tr.find("td", attrs={"data-event-datetime": True})
            dt_attr = td_time.get("data-event-datetime") if td_time else None
        if not dt_attr:
            continue
        dt_utc_iso = dt_attr.replace("T", " ").replace("Z", "")
        if len(dt_utc_iso) == 16:
            dt_utc_iso += ":00"

        # название
        td_event = tr.find("td", class_=re.compile("event", re.I))
        name = td_event.get_text(" ", strip=True) if td_event else ""
        if not name:
            continue

        # валюта/страна
        td_cur = tr.find("td", class_=re.compile("flagCur", re.I))
        cur = td_cur.get_text(strip=True) if td_cur else "USD"
        country = "US" if "USD" in cur else cur.upper()

        # важность (быки/звёзды/точки)
        td_sent = tr.find("td", class_=re.compile("sentiment", re.I))
        imp_html = str(td_sent) if td_sent else ""
        stars = len(re.findall(r"(?i)icon-bullish|bullishIcon|forex-calendar-bull-(?:1|2|3)|fullStar|icon-star-full", imp_html))
        if stars == 0:
            stars = imp_html.count("•")
        importance = max(0, min(3, stars))

        # prev/forecast/actual
        def cell_text(cls: str) -> str:
            td = tr.find("td", class_=re.compile(cls, re.I))
            return td.get_text(strip=True) if td else ""

        actual = cell_text("actual")
        forecast = cell_text("forecast")
        previous = cell_text("previous")

        out.append({
            "id": _stable_id(name, dt_utc_iso, country, importance),
            "date_utc": dt_utc_iso,          # строка 'YYYY-MM-DD HH:MM:SS'
            "event_name": name,              # уже придёт по‑русски при lang=7 + заголовке Accept-Language
            "country": country,
            "currency": "USD" if country == "US" else country,
            "importance": importance,
            "previous": previous,
            "forecast": forecast,
            "actual": actual,
        })

    print(f"[scraper] parsed events: {len(out)}")
    return out


# ---------- публичный API ----------
async def scrape_investing_us() -> List[Dict]:
    html = await fetch_calendar()
    events = parse_events(html)
    # фильтруем минимум «1 звезда» и только США
    return [e for e in events if e.get("importance", 0) >= 1 and e.get("country") == "US"]


async def scrape_and_upsert() -> None:
    from app.db import upsert_events
    try:
        events = await scrape_investing_us()
        if not events:
            print("[scraper] no events parsed")
            return

        rows = []
        for e in events:
            dt = datetime.strptime(e["date_utc"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc).replace(tzinfo=None)
            rows.append((
                e["id"],
                dt,                      # dt_utc как datetime (UTC naive) — как в твоём проекте
                e["country"],
                e["event_name"],
                int(e["importance"]),
                e.get("previous") or "",
                e.get("forecast") or "",
                e.get("actual") or "",
            ))

        upsert_events(rows)
        print(f"[scraper] inserted/updated {len(rows)} events")
    except Exception as ex:
        print(f"[scraper] error: {ex}")
