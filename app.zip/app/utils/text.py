import hashlib, re
from datetime import datetime
def stable_id(*parts: str) -> str:
    s = "|".join([p.strip() for p in parts if p is not None])
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:24]
def parse_date_header(s: str) -> datetime:
    return datetime.strptime(s.strip(), "%A, %B %d, %Y")
def clean_space(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()
