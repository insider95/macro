# app/scheduler.py
from __future__ import annotations

# 1) подхватываем .env до чтения путей
from dotenv import load_dotenv
load_dotenv()

import os
from datetime import datetime, timedelta, timezone

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore

from app.db import _conn, get_user, list_blacklist, events_between
from app.notifier import send_alert
from app.ai import analyze_event_if_needed

# === JobStore path из .env ===
JOB_DB_PATH = os.getenv("APSCHEDULER_SQLITE_PATH", "jobs.sqlite")
_job_dir = os.path.dirname(JOB_DB_PATH)
if _job_dir:
    os.makedirs(_job_dir, exist_ok=True)

scheduler = AsyncIOScheduler(jobstores={"default": SQLAlchemyJobStore(url=f"sqlite:///{JOB_DB_PATH}")})

def start_scheduler():
    scheduler.add_job(refresh_events, "cron", minute=5, id="refresh_events_hourly", replace_existing=True)
    scheduler.add_job(tick_timers, "cron", minute="*/5", id="tick_timers_5m", replace_existing=True)
    scheduler.add_job(check_facts, "cron", minute="*/3", id="check_facts_3m", replace_existing=True)
    scheduler.start()

# === Jobs ===
async def refresh_events():
    try:
        from app.scraper import scrape_and_upsert
        await scrape_and_upsert()
    except Exception as e:
        print(f"[scheduler] refresh_events error: {e}")

async def tick_timers():
    try:
        now = datetime.now(timezone.utc)
        in_24 = now + timedelta(hours=24)
        in_30m = now + timedelta(minutes=30)

        with _conn() as c:
            chats = [r[0] for r in c.execute("SELECT chat_id FROM users").fetchall()]

        for chat_id in chats:
            u = get_user(chat_id)
            bl = list_blacklist(chat_id)

            if "t24" in (u["alert_mode"] or ""):
                evs_24 = events_between(in_24 - timedelta(minutes=2), in_24 + timedelta(minutes=3),
                                        country=u["country"], imp_min=u["importance_min"], imp_max=u["importance_max"],
                                        blacklist_patterns=bl)
                for e in evs_24:
                    await send_alert(chat_id, e, kind="t24")

            if "t30" in (u["alert_mode"] or ""):
                evs_30 = events_between(in_30m - timedelta(minutes=2), in_30m + timedelta(minutes=3),
                                        country=u["country"], imp_min=u["importance_min"], imp_max=u["importance_max"],
                                        blacklist_patterns=bl)
                for e in evs_30:
                    await send_alert(chat_id, e, kind="t30")
    except Exception as e:
        print(f"[scheduler] tick_timers error: {e}")

async def check_facts():
    try:
        now = datetime.now(timezone.utc)
        window_start = now - timedelta(minutes=10)
        window_end = now + timedelta(minutes=2)

        with _conn() as c:
            chats = [r[0] for r in c.execute("SELECT chat_id FROM users").fetchall()]

        for chat_id in chats:
            u = get_user(chat_id)
            if "fact" not in (u["alert_mode"] or ""):
                continue
            bl = list_blacklist(chat_id)
            evs = events_between(window_start, window_end, country=u["country"],
                                 imp_min=u["importance_min"], imp_max=u["importance_max"],
                                 blacklist_patterns=bl)
            for e in evs:
                if e.get("actual"):
                    analysis = await analyze_event_if_needed(e)
                    await send_alert(chat_id, e, kind="fact", analysis=analysis)
    except Exception as e:
        print(f"[scheduler] check_facts error: {e}")
