# app/formatting.py
from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo

RU_MONTHS = [
    "", "января", "февраля", "марта", "апреля", "мая", "июня",
    "июля", "августа", "сентября", "октября", "ноября", "декабря"
]

def _ru_date(dt: datetime) -> str:
    return f"{dt.day} {RU_MONTHS[dt.month]} {dt.year}"

def format_event_for_user(event: dict, tz_name: str = "Europe/Moscow") -> str:
    """
    event: { id, dt_utc, country, name, importance, previous, forecast, actual }
    """
    utc = datetime.strptime(str(event["dt_utc"]), "%Y-%m-%d %H:%M:%S").replace(tzinfo=ZoneInfo("UTC"))
    local = utc.astimezone(ZoneInfo(tz_name))
    date_part = _ru_date(local)
    time_part = local.strftime("%H:%M")

    name = (event.get("name") or "").strip()
    prev = (event.get("previous") or "").strip() or "—"
    fcst = (event.get("forecast") or "").strip() or "—"
    act  = (event.get("actual")   or "").strip()

    lines = [
        f"📅 {date_part} в {time_part} (Москва)",
        f"👉 {name}",
        f"🔘 Пред: {prev}",
        f"🔘 Прогноз: {fcst}",
    ]
    if act:
        lines.append(f"🔘 Факт: {act}")
    return "\n".join(lines)

def chunk_messages(blocks: list[str], limit: int = 8) -> list[str]:
    out, buf = [], []
    for b in blocks:
        buf.append(b)
        if len(buf) >= limit:
            out.append("\n\n".join(buf))
            buf = []
    if buf:
        out.append("\n\n".join(buf))
    return out
