# app/bot.py
import os
import asyncio
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand

from app.db import init_db
from app.scheduler import start_scheduler
from app import notifier as notifier_module

# роутеры
from app.handlers import start, filters, next as next_events, admin, settings, importance, alerts
from app.handlers import blacklist, range as range_handlers, help as help_router
from app.handlers import debug as debug_router
from app.handlers import dbinfo as dbinfo_router

async def run():
    # БД
    init_db()

    # Бот
    bot = Bot(
        token=os.getenv("BOT_TOKEN"),
        default=DefaultBotProperties(parse_mode=ParseMode.HTML)
    )
    dp = Dispatcher(storage=MemoryStorage())

    # сделать Bot доступным для notifier
    notifier_module.bot = bot

    # Подключаем роутеры
    dp.include_router(start.router)
    dp.include_router(settings.router)
    dp.include_router(importance.router)
    dp.include_router(alerts.router)
    dp.include_router(filters.router)
    dp.include_router(next_events.router)
    dp.include_router(blacklist.router)
    dp.include_router(range_handlers.router)
    dp.include_router(help_router.router)
    dp.include_router(admin.router)  # в конце
    dp.include_router(debug_router.router)
    dp.include_router(dbinfo_router.router)

    # Меню команд в Telegram
    await bot.set_my_commands([
        BotCommand(command="start", description="Приветствие"),
        BotCommand(command="settings", description="Мои настройки"),
        BotCommand(command="importance", description="Выбор важности"),
        BotCommand(command="alerts", description="Варианты уведомлений"),
        BotCommand(command="blacklist", description="Чёрный список"),
        BotCommand(command="week", description="События этой недели"),
        BotCommand(command="nextweek", description="События следующей недели"),
        BotCommand(command="month", description="События месяца"),
        BotCommand(command="help", description="Список команд"),
    ])

    # Планировщик
    start_scheduler()

    # Старт поллинга
    await dp.start_polling(bot)


# алиас для совместимости с main.py (from app.bot import main)
main = run

if __name__ == "__main__":
    asyncio.run(run())
