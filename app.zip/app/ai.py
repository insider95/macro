# app/ai.py
import os, asyncio
import json
from typing import Optional

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

async def analyze_event_if_needed(e: dict) -> Optional[str]:
    if not OPENAI_API_KEY:
        return None
    # очень короткий промпт; можешь расширить стилем канала
    prompt = (
        "Ты крипто-макро аналитик. Коротко в 2-3 пунктах, как опубликованный факт по событию "
        f"'{e['name']}' может повлиять на BTC в ближайшие 24-72 часа. "
        f"Дано: previous={e['previous']}, forecast={e['forecast']}, actual={e['actual']}. "
        "Пиши кратко и по делу, без воды."
    )
    try:
        # тут используй любой клиент к Chat Completions. Псевдокод без внешних зависимостей:
        import httpx
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
                json={
                    "model": "gpt-4o-mini",
                    "messages": [{"role":"system","content":"Ты лаконичный аналитик."},
                                 {"role":"user","content":prompt}],
                    "temperature": 0.3,
                    "max_tokens": 220
                }
            )
        data = r.json()
        return data["choices"][0]["message"]["content"].strip()
    except Exception:
        return None
