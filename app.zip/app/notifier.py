# app/notifier.py
from aiogram import Bot
from datetime import datetime
from app.db import _conn

bot: Bot = None  # инициализируй в app/bot.py после создания

def _already_sent(chat_id: int, event_id: str, kind: str) -> bool:
    with _conn() as c:
        row = c.execute("SELECT 1 FROM alerts WHERE chat_id=? AND event_id=? AND kind=?",
                        (chat_id, event_id, kind)).fetchone()
        return bool(row)

def _mark_sent(chat_id: int, event_id: str, kind: str):
    with _conn() as c:
        c.execute("INSERT OR IGNORE INTO alerts(chat_id, event_id, kind) VALUES(?,?,?)",
                  (chat_id, event_id, kind))

def _badge(imp: int) -> str:
    return {1:"•",2:"••",3:"•••"}.get(imp,"•")

async def send_alert(chat_id: int, e: dict, kind: str, analysis: str | None = None):
    if _already_sent(chat_id, e["id"], kind):
        return
    txt = f"{_badge(e['importance'])} {e['name']}\n"
    txt += f"{e['dt_utc']} UTC\n"
    if kind in ("t24","t30"):
        txt += f"Напоминание: {('за 24 часа' if kind=='t24' else 'за 30 минут')}.\n"
        txt += f"Прогноз: {e['forecast'] or '-'} | Предыдущее: {e['previous'] or '-'}"
    else:
        txt += f"Факт: {e['actual'] or '-'} | Прогноз: {e['forecast'] or '-'} | Предыдущее: {e['previous'] or '-'}"
        if analysis:
            txt += f"\n\nРазбор: {analysis}"
    await bot.send_message(chat_id, txt)
    _mark_sent(chat_id, e["id"], kind)
