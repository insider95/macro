import os
from dotenv import load_dotenv
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = BASE_DIR / ".env"
if ENV_PATH.exists():
    load_dotenv(ENV_PATH)
else:
    load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5")
OWNER_ID = int(os.getenv("OWNER_ID", "0") or "0")

TZ = os.getenv("TZ", "Asia/Almaty")
SQLITE_PATH = os.getenv("SQLITE_PATH", "data/bot.db")
APSCHEDULER_SQLITE_PATH = os.getenv("APSCHEDULER_SQLITE_PATH", "data/jobs.sqlite")

DEFAULT_COUNTRY = os.getenv("DEFAULT_COUNTRY", "US")
DEFAULT_IMPORTANCE_MIN = int(os.getenv("DEFAULT_IMPORTANCE_MIN", "2"))
DEFAULT_IMPORTANCE_MAX = int(os.getenv("DEFAULT_IMPORTANCE_MAX", "3"))

INVESTING_COUNTRIES = os.getenv("INVESTING_COUNTRIES", "5")
INVESTING_CALTYPE = os.getenv("INVESTING_CALTYPE", "week")
INVESTING_LANG = os.getenv("INVESTING_LANG", "1")
INVESTING_TZ_ID = os.getenv("INVESTING_TZ_ID", "").strip()
INVESTING_COOKIE = os.getenv("INVESTING_COOKIE", "").strip()
USE_PLAYWRIGHT = bool(os.getenv("USE_PLAYWRIGHT", "").strip())

DATA_DIR = BASE_DIR / "app" / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = BASE_DIR / SQLITE_PATH
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

JOBS_DB_PATH = BASE_DIR / APSCHEDULER_SQLITE_PATH
JOBS_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
